#ifndef __CONSTS_H
#define __CONSTS_H

#define SIZE 150
#define AMOUNT_OF_STARTED_ITEMS 5
#define STAYING 1
#endif
